This directory contains useful definitions of tools 
for the Code::Blocks "Tools" menu.
====================================================

The definitions found in the .xml files below can be added to
Code::Blocks by editing the <tools> </tools> section of the 
Code::Blocks "default.conf" file.

Code::Blocks "default.conf" is found in the following places:
Windows:  C:\Documents and Settings\<USER>\Application Data\codeblocks
Linux:    ~/.codeblocks

The following files are provided 
CB_tools_win.xml  	: Windows-specific tools numbered in the range [1-9] 
CB_tools_ux.xml  	: Linux-specific tools numbered in the range [1-9] 
CB_tools_QBZR.xml	: Portable QBZR tools numbered from 10+

The idea here is that you can edit default.conf on both Win and Linux to 
get all the tools defined. Simply copy/paste from the xml files.

If you want to use QBZR source control, bzr and QBZR must be installed
Windows:  http://wiki.bazaar.canonical.com/WindowsDownloads
Linux:	  $sudo apt-get install qbzr

Step-by-step instructions:
0) Before you start, make sure Code::Blocks is not running.
1) open default.conf using a text editor and find the <tools> tag.
2) Delete everything between <tools> and </tools>
3) Add platform specific tool definitions: 
   3.1 Windows: copy everything between <tools> and </tools> 
       from CB_tools_win.xml to same location in default.conf
   3.2 Linux:  copy everything between <tools> and </tools> 
       from CB_tools_ux.xml to same location in default.conf
4) Add generic QBZR tools on Win and Linux
   copy everything between <tools> and </tools> 
   from CB_tools_QBZR.xml to corresponding in default.conf,
   placing it *after* the tools added above.
	   
This will imply that there will be some "holes" in the numbering of 
tools, but this appears to be handled OK by Code::Blocks (overlapping
tool numbering does *not* work).

Now you can start Code::Blocks and use the entries in the Tools menu.

   --- o 0 o ---